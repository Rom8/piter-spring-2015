package qualifiers;

/**
 * Created by Jeka on 15/10/2015.
 */
public interface Dao {
    void save() throws InterruptedException;
}
