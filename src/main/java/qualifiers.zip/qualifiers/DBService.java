package qualifiers;

/**
 * Created by Jeka on 15/10/2015.
 */
public interface DBService {
    void doStuff() throws InterruptedException;
}
